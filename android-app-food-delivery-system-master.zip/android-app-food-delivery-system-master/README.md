# android-app-food-delivery-system
Its an Android app for delivery food. Client can order by website or this app. And a notification will be sent to food delivery boy
who will be the 12 km radius of client place with order details. If he accept the order, another notification will be sent to client 
with delivery boy details. And if he reject the order then app will search another rider and will send notification to another delivery 
boy who are in 12 km radius of client place. actually app makes a list of rider who are available within 12 km distance radius . If no 
delivery boy is found then client will get another notification that no delivery boy is found. This radius of distance is dynamic as it 
can be changed from cms. 
