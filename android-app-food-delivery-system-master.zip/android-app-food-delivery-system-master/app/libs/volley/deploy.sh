#!/usr/bin/env bash
./gradlew -x test clean assembleRelease uploadArchives
